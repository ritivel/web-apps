
import MainPage from '../page/main';

var routes = [
    {
        path: '/',
        component: MainPage,
    }
];

export default routes;
