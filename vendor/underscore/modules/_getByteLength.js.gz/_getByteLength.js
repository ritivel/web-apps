import shallowProperty from './_shallowProperty.js';

// Internal helper to obtain the `byteLength` property of an object.
export default shallowProperty('byteLength');
