module.exports = require('eslint-plugin-github/prettier.config')
