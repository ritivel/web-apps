define("omega",
  function() {
    return {
      version: 2
    };
  }
);
