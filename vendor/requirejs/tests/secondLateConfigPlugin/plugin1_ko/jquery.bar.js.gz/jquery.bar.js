
jQuery.bar = "jQuery BAR here!";
