define(['bar'], function (bar) {
  return {
    name: 'app',
    bar: bar
  };
});

