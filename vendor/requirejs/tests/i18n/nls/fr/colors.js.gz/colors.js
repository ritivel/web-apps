define({
    red: "rouge",
    blue: "bleu"
});
