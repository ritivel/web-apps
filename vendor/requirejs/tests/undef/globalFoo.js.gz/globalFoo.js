var globalFoo = {
    name: 'globalFoo'
};

