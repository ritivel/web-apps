define(["require", "exports", "module", "hasOwnProperty","toString","test"], function(require, exports, module) {
var hasOwnProperty = require('hasOwnProperty');
var toString = require('toString');
var test = require('test');
test.print('DONE', 'info');

});
