define({
    name: 'two'
});
