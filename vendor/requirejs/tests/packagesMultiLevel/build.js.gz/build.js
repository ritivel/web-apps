{
  name: 'packagesMultiLevel-tests',
  out: 'packagesMultiLevel-tests-built.js',
  mainConfigFile: 'config.js',
  optimize: 'none'
}
