define("red", function () {
    return {
        name: "red"
    };
});