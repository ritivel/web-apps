define(['component'], function (component) {
    return {
        name: 'collectionHelper',
        componentName: component.name,
        componentHtml: component.html
    };
});
