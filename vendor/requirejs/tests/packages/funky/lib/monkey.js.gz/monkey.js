define({
    name: 'monkey'
});
