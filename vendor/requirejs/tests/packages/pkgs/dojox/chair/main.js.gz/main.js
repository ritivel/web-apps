define(['./legs'], function (legs) {
    return {
        name: 'dojox/chair',
        legsName: legs.name
    }
});
