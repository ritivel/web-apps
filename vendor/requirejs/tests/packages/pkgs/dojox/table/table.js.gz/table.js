define(['dojox/chair'], function (chair) {
    return {
        name: 'dojox/table',
        chairName: chair.name
    };
});
