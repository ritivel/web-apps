define({
    name: "baz/helper"
});
