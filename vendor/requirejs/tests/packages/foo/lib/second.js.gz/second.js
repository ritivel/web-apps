define({
    name: 'foo/second'
});
