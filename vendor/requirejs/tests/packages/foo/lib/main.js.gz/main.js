define(function (require, exports) {    
    exports.name = 'foo';
    exports.alphaName = require('alpha').name;
});
