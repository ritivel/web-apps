var C = {
    name: 'c',
    a: A,
    b: B
};
