define("funcSet",
            ["require", "exports", "module"],
            function (require, exports, module) {
    module.exports = "funcSet";
});
