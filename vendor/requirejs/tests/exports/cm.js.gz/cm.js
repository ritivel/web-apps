define([
    'module',
    'exports'
], function (module, exports) {
    exports.name = 'cm';
});
